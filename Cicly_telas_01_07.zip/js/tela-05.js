document.getElementById("continueButton").addEventListener("click", () => {
  window.location.href = "tela-06.html";
});
