const form = document.getElementById("registerForm");

form.addEventListener("submit", (event) => {
  event.preventDefault();

  const values = Object.fromEntries(new FormData(form));

  if (values.senha !== values.confirmarSenha) {
    alert("As senhas não são iguais.");
    return;
  }

  localStorage.setItem("ciclyCadastro", JSON.stringify(values));
  window.location.href = "tela-04.html";
});
