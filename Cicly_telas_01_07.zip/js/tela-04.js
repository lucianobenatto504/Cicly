document.getElementById("gestationButton").addEventListener("click", () => {
  localStorage.setItem("ciclyModo", "gestacao");
  alert("O fluxo de gestação será conectado quando chegarmos nessas telas.");
});

document.getElementById("menstruationButton").addEventListener("click", () => {
  localStorage.setItem("ciclyModo", "menstruacao");
  window.location.href = "tela-05.html";
});
