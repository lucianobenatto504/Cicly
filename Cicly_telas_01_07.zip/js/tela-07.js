document.querySelectorAll(".help-option").forEach((button) => {
  button.addEventListener("click", () => {
    const page = button.dataset.page;

    if (page === "absorventes") {
      alert("A próxima tela de tipos de absorventes será conectada no próximo print.");
      return;
    }

    alert(`Opção selecionada: ${page}`);
  });
});

document.getElementById("noButton").addEventListener("click", () => {
  localStorage.setItem("ciclyPrimeiraMenstruacao", "nao");
});

document.getElementById("yesButton").addEventListener("click", () => {
  localStorage.setItem("ciclyPrimeiraMenstruacao", "sim");
});
