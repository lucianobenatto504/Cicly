document.getElementById("noButton").addEventListener("click", () => {
  localStorage.setItem("ciclyPrimeiraMenstruacao", "nao");
  window.location.href = "tela-07.html";
});

document.getElementById("yesButton").addEventListener("click", () => {
  localStorage.setItem("ciclyPrimeiraMenstruacao", "sim");
  window.location.href = "tela-07.html";
});
