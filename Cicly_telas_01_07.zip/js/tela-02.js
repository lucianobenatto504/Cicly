document.getElementById("nextScreen").addEventListener("click", () => {
  window.location.href = "tela-03.html";
});
