document.getElementById("openApp").addEventListener("click", () => {
  window.location.href = "tela-02.html";
});
