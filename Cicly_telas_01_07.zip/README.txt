CICLY — TELAS 01 A 07

Abra index.html.

Fluxo atual:
Tela 01 -> Tela 02 -> Tela 03 -> Tela 04 -> Tela 05 -> Tela 06 -> Tela 07

As telas 05, 06 e 07 foram recriadas com base nos prints enviados.
